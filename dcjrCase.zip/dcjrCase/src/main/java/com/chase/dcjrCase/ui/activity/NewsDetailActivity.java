package com.chase.dcjrCase.ui.activity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ProgressBar;

import com.chase.dcjrCase.R;


public class NewsDetailActivity extends AppCompatActivity{

    private ImageButton btnBack;
    private ImageButton btnMenu;
    private ImageButton btnTextSize;
    private ImageButton btnShare;
    private WebView mWebView;
    private ProgressBar pbLoading;
    private String mUrl;
    private LinearLayout llController;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_case_detail);

//        btnBack = (ImageButton) findViewById(R.id.btn_back);
//        btnMenu = (ImageButton) findViewById(R.id.btn_menu);
//        btnTextSize = (ImageButton) findViewById(R.id.btn_textsize);
//        btnShare = (ImageButton) findViewById(R.id.btn_share);
        mWebView = (WebView) findViewById(R.id.wv_webview);
        pbLoading = (ProgressBar) findViewById(R.id.pb_loading);
//        llController = (LinearLayout) findViewById(R.id.ll_controller);

//        btnBack.setOnClickListener(this);
//        btnTextSize.setOnClickListener(this);
//        btnShare.setOnClickListener(this);
//
//        btnBack.setVisibility(View.VISIBLE);
//        btnMenu.setVisibility(View.GONE);
//        llController.setVisibility(View.VISIBLE);

//        mUrl = getIntent().getStringExtra("url");

        // 加载网页
//        mWebView.loadUrl("http://www.itcast.cn/");
        mWebView.loadUrl("http://www.emcmark.com/article-64-1.html");

        WebSettings settings = mWebView.getSettings();
        settings.setBuiltInZoomControls(true);// 显示放大缩小按钮
        settings.setUseWideViewPort(true);// 只是双击缩放
        settings.setJavaScriptEnabled(true);// 打开js功能

        mWebView.setWebViewClient(new WebViewClient() {
            // 网页开始加载
            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                super.onPageStarted(view, url, favicon);
                System.out.println("网页开始加载");
                pbLoading.setVisibility(View.VISIBLE);
            }


            // 网页跳转
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                System.out.println("网页跳转:" + url);
                view.loadUrl(url);// 强制在当前页面加载网页, 不用跳浏览器
                return true;

            }

            // 网页加载结束
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                System.out.println("网页加载结束");
                pbLoading.setVisibility(View.GONE);
            }
        });

        mWebView.setWebChromeClient(new WebChromeClient() {
            // 加载进度回调
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                super.onProgressChanged(view, newProgress);
                System.out.println("newProgress:" + newProgress);
                pbLoading.setMax(100);
                pbLoading.setProgress(newProgress);//设置水平进度条进度
            }

            // 网页标题
            @Override
            public void onReceivedTitle(WebView view, String title) {
                super.onReceivedTitle(view, title);
                System.out.println("title:" + title);
            }
            //网页图标

            @Override
            public void onReceivedIcon(WebView view, Bitmap icon) {
                super.onReceivedIcon(view, icon);
            }
        });
    }

    /*@Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn_back:
                finish();
                break;
            case R.id.btn_textsize:
                showChooseDialog();
                break;
            case R.id.btn_share:

                break;
        }
    }*/


    // 点击确定前, 用户选择的字体大小的位置
    private int mChooseItem;
    // 当前的字体位置
    private int mSelectItem = 2;

    /**
     * 选择字体大小的弹窗
     */
    private void showChooseDialog() {
        final AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("字体设置");
        String[] item = new String[]{"超大号字体", "大号字体", "正常字体", "小号字体", "超小号字体"};
        builder.setSingleChoiceItems(item, mSelectItem, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                mChooseItem = which;
            }
        });
        builder.setPositiveButton("确定", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                WebSettings settings = mWebView.getSettings();
                switch (mChooseItem) {
                    case 0:
                        settings.setTextSize(WebSettings.TextSize.LARGEST);
//                        settings.setTextZoom(25);  手动设置字体大小,需要android4.0以上才可以
                        break;
                    case 1:
                        settings.setTextSize(WebSettings.TextSize.LARGER);
                        break;
                    case 2:
                        settings.setTextSize(WebSettings.TextSize.NORMAL);
                        break;
                    case 3:
                        settings.setTextSize(WebSettings.TextSize.SMALLER);
                        break;
                    case 4:
                        settings.setTextSize(WebSettings.TextSize.SMALLEST);
                        break;
                }
                mSelectItem = mChooseItem;
            }
        });
        builder.setNegativeButton("取消", null);
        builder.show();
    }
}
