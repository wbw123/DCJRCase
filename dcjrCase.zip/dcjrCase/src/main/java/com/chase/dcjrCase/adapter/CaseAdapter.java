package com.chase.dcjrCase.adapter;

import android.app.Activity;
import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.chase.dcjrCase.R;
import com.chase.dcjrCase.bean.CaseData.DataBean.CaseDataBean;
import com.chase.dcjrCase.ui.fragment.CaseFragment;

import java.util.ArrayList;

/**
 * Created by chase on 2017/9/7.
 */

public class CaseAdapter extends BaseAdapter {
    private ArrayList<CaseDataBean> mCaseList;
    private Context mContext;
    private int mCount;


    public CaseAdapter(Activity mActivity, ArrayList<CaseDataBean> listItems) {
        this.mCaseList = listItems;
        this.mContext = mActivity;
    }

    @Override
    public int getCount() {
        mCount = CaseFragment.getCount();
        if (mCount >= mCaseList.size()){
            System.out.println(mCaseList.size()+"===================");
            return mCaseList.size();

        }else {
            System.out.println(mCount+"========================");
            return mCount;
        }
    }

    @Override
    public CaseDataBean getItem(int position) {
        return mCaseList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder = null;
        if (convertView == null) {
            convertView = View.inflate(mContext, R.layout.item_case_list, null);
            holder = new ViewHolder(convertView);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        CaseDataBean item = getItem(position);
//        holder.iv_image.setImageResource();
        holder.tv_title.setText(item.title);
        holder.tv_date.setText(item.date);
        return convertView;
    }

    class ViewHolder {

        public ImageView iv_image;
        public TextView tv_title;
        public TextView tv_date;

        public ViewHolder(View view) {
            iv_image = view.findViewById(R.id.iv_case_image);
            tv_title = view.findViewById(R.id.tv_case_title);
            tv_date = view.findViewById(R.id.tv_case_date);
        }
    }

}
