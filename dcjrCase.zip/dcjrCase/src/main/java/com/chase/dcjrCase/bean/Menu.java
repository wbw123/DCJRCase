package com.chase.dcjrCase.bean;

/**
 * Created by chase on 2017/9/4.
 */

public class Menu {
    public String menuName;
    public int menuPicId;
}
